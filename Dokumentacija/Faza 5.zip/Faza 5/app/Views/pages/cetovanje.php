<!--
Autori: Nikola Nikolic 2020/0357
-->
    <div class="cont">
        <div class="chat-box">
            <!-- <div class="message your-message">
                <span class="usernameChat">John:</span><br>
                <span class="contentChat">Hey, how are you?</span>
                <span class="timestampChat">10-01-2002 13:56:31</span>
            </div>
            <div class="message other-message">
                <span class="usernameChat">Sarah:</span><br>
                <span class="contentChat">I'm good, thanks! How about you?</span>
                <span class="timestampChat">12-01-2002 20:43:16</span>
            </div> -->
            <!-- More messages can be added here -->
        </div>
        <div class="input-box">
            <input type="text" id="message-input-chat" placeholder="Unesite Vašu poruku...">
            <div class="col-sm-1">
                <button class="btn btn-dark text-yellow" id="send-button-chat">Pošalji</button>
            </div>
        </div>
    </div>
  </div>
</body>

</html>