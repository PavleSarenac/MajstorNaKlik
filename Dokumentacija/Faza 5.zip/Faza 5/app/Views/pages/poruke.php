<!--
Autori:
Nikola Nikolic 2020/0357
-->
<div class="container-messages text-center col-sm-8 offset-sm-2">
            <div class="row">
                <div class="col">
                    <h1><strong>Prikaz poruka: </strong></h1>
                </div>
            </div>
            <!-- <div class="row person" id="3">
                <h2>John Doe</h2>
                <span>Broj neprocitanih poruka: </span>
                <span>10</span>
            </div>

            <div class="row person" id="4">
                <h2>Jane Smith</h2>
                <span>Broj neprocitanih poruka: </span>
                <span>5</span> -->
            </div>
            <!-- Add more divs for additional names and their respective number of messages -->
        </div>
    </div>
</body>

</html>
