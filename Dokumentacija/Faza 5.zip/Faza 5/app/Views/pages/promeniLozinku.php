<!--
Autori: 
Ljubica Majstorovic 2020/0253
-->
        <div class="row text-center">
            <h1><strong>Ažuriraj lozinku:</strong></h1>
        </div>
        <div class="row">
            <form action="">
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <input type="text" class="form-control" placeholder="Unesite novu lozinku...">
                    </div>
                    <div class="col"></div>
                </div>
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <input type="text" class="form-control" placeholder="Potvrdite novu lozinku...">
                    </div>
                    <div class="col"></div>
                </div>
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <button type="submit" class="btn btn-dark text-yellow">Ažuriraj</button>
                    </div>
                    <div class="col"></div>
                </div>
            </form>
        </div>
    </div>
</body>

</html>